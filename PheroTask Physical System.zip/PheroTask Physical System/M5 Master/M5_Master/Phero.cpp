#include "phero.h"

Phero_c::Phero_c() {
  // Constructor implementation
}



void Phero_c::initialise() {

  goalcell_x = PMAP_START_X;
  goalcell_y = PMAP_START_Y;
  pmap_x = PMAP_START_X;
  pmap_y = PMAP_START_Y;
  prev_x = PMAP_START_X;
  prev_y = PMAP_START_Y;
  fwdX_global = pmap_x + 1; // assume facing 0 deg (right) at start!
  fwdY_global = pmap_y;


  //  evaporation = 0.003;

  // Randomise pheromone group
  if ((int)random(0, 2) == 1) {
    phero_type = PHERO_A;
  } else {
    phero_type = PHERO_B;
  }
  // Start at local pmap for hybrid messaging
  message_index_hybrid = 0;

  // Group sizes
  groupA_size = 0;
  groupB_size = 0;
  // targetA_size set in main loop
  targetB_size = 1 - targetA_size;
  group_switches = 0;

  //  message_type = 0; // sending local pmap cells
  //  hysteresis; // 5% hysteresis to prevent rapid switching
  //  R_PHERO;

  initialised = false;
  local_msg = true;

  // Initialise map with 0
  for (int y = 0; y < PMAP_MAX; y++) {
    for (int x = 0; x < PMAP_MAX; x++) {
      pmap[y][x] = 0;
    }
  }


  for (int i = 0; i < sizeof(encoding_table); i++) {
    decoding_table[(int)encoding_table[i]] = i;
  }

}

void Phero_c::update() {
  updatePmapxy(); // note: columns = x of pmap, rows = y of pmap
  //  fwdCell(ThetaRange360());


  groupEstimate(pmap, pmap_x, pmap_y);
  groupChange(phero_type, groupA_size, groupB_size, targetA_size, targetB_size, hysteresis);

  //  detection(pmap, pmap_x, pmap_y, 0);
  deposition(pmap, pmap_x, pmap_y, evaporation, phero_type);
  initialised = true;

}

// Deposition of pheromone
// Phero Type: 'A' (Group A), 'B' (Group B)
void Phero_c::deposition(float _pmap[PMAP_MAX][PMAP_MAX], int _pmap_x, int _pmap_y, float evap, char _phero_type) {
  // Ensure the indices are within the bounds
  if (_pmap_x < 0 || _pmap_x >= PMAP_MAX || _pmap_y < 0 || _pmap_y >= PMAP_MAX
      || (_phero_type != PHERO_A && _phero_type != PHERO_B)) {
    return; // out of bounds or incorrect option, do nothing
  }


  for (int y = 0; y < PMAP_MAX; y++) {
    for (int x = 0; x < PMAP_MAX; x++) {

      int max_phero;
      int min_phero;
      int8_t radius = (int)max(abs(y - _pmap_y), abs(x - _pmap_x)); // Manhattan distance

      // If cell is within robot's view radius (also changes neighbour pheromone to own if in radius and laying pheromone)
      if (radius <= R_PHERO) {
        double diffusion = 0.5 * pow((0.1 * exp(1)), (2 * (radius / PI)));

        max_phero = (_phero_type == PHERO_A) ? max_A : max_B;
        min_phero = max_phero - 1;

        if (_pmap[y][x] < min_phero) _pmap[y][x] = min_phero; // prevents local pheromone values from going below range

        _pmap[y][x] += (max_phero - _pmap[y][x]) * diffusion; // Deposition of pheromone within radius

        if (_pmap[y][x] > max_phero) _pmap[y][x] = max_phero; // prevents value from exceeding relative maximum
        //          Serial.println("New value added for attraction: " + String(_pmap[y][x]));
      }


      if (_pmap[y][x] > 0) {
        if (_pmap[y][x] <= 1) {
          _pmap[y][x] -= _pmap[y][x] * evap;
        } else { // Use decimal component for other ranges greater than 1
          float aux = fmod(_pmap[y][x], 1.0f);
          _pmap[y][x] -= aux * evap;
        }

        //Below to reset neighbour pheromone ranges when below lower limit:
        if (_pmap[y][x] > 1 && _pmap[y][x] < 2) _pmap[y][x] = 0; // reset local B phero
        if (_pmap[y][x] > 9 && _pmap[y][x] < 10) _pmap[y][x] = 0; // reset neighbour A phero
        if (_pmap[y][x] > 11 && _pmap[y][x] < 12) _pmap[y][x] = 0; // reset neighbour B phero

      }
    }
  }
}

void Phero_c::groupEstimate(float _pmap[PMAP_MAX][PMAP_MAX], int _pmap_x, int _pmap_y) {
  float group_A = 0;
  float group_B = 0;
  float valid_cells = 0;
  for (int y = 0; y < PMAP_MAX; y++) {
    for (int x = 0; x < PMAP_MAX; x++) {

      //      // Skips R_PHERO grid
      //      for (int dx = -R_PHERO; dx <= R_PHERO; dx++) {
      //        for (int dy = -R_PHERO; dy <= R_PHERO; dy++) {
      //          if (x == _pmap_x + dx && y == _pmap_y + dy) {
      //            continue;  // Skip this iteration of the outer loop
      //          }
      //        }
      //      }

      // Skip local 3x3 neighbourhood
      if (x == _pmap_x - 1 && y == _pmap_y - 1) continue;
      if (x == _pmap_x  && y == _pmap_y - 1) continue;
      if (x == _pmap_x + 1 && y == _pmap_y - 1) continue;
      if (x == _pmap_x - 1 && y == _pmap_y ) continue;
      if (x == _pmap_x  && y == _pmap_y ) continue;
      if (x == _pmap_x + 1 && y == _pmap_y ) continue;
      if (x == _pmap_x - 1 && y == _pmap_y + 1) continue;
      if (x == _pmap_x  && y == _pmap_y + 1) continue;
      if (x == _pmap_x + 1 && y == _pmap_y + 1) continue;

      if (_pmap[y][x] > 0) { // Only adds if there is a value > 0
        if ( (_pmap[y][x] > 0 && _pmap[y][x] <= 1) ||
             (_pmap[y][x] > 10 && _pmap[y][x] <= 11)) {
          group_A += 1;
        } else if ( (_pmap[y][x] > 2 && _pmap[y][x] <= 3) ||
                    (_pmap[y][x] > 12 && _pmap[y][x] <= 13)) {
          group_B += 1;
        } else {
          // Should not be a pmap[y][x] out of these ranges
        }
        //valid_cells += 1;
      }
    }
  }
  valid_cells = group_A + group_B;
  if (valid_cells > 0) {
    groupA_size = group_A / valid_cells;
    groupB_size = group_B / valid_cells;
  }
}

void Phero_c::groupChange(char current_group, float _groupA_size, float _groupB_size, float tgt_val_A, float tgt_val_B, float hysteresis) {
  float transition_prob;

  if (current_group == 'A') {
    if (_groupA_size > tgt_val_A * (1 + hysteresis)) {
      // Probabilistic transition based on how far we are above the target
      transition_prob = (_groupA_size - tgt_val_A) / tgt_val_A;
      if (random(0, 1) < transition_prob) {
        phero_type = PHERO_B;
        group_switches += 1;
      }
    }
  } else { // current_group == 'B'
    if (_groupB_size > tgt_val_B * (1 + hysteresis)) {
      transition_prob = (_groupB_size - tgt_val_B) / tgt_val_B;
      if (random(0, 1) < transition_prob) {
        phero_type = PHERO_A;
        group_switches += 1;
      }
    }
  }

  // Consider switching if the other group is significantly under target
  if (current_group == 'A' && _groupB_size < tgt_val_B * (1 - hysteresis)) {
    transition_prob = (tgt_val_B - _groupB_size) / tgt_val_B;
    if (random(0, 1) < transition_prob) {
      phero_type = PHERO_B;
    }
  } else if (current_group == 'B' && _groupA_size < tgt_val_A * (1 - hysteresis)) {
    transition_prob = (tgt_val_A - _groupA_size) / tgt_val_A;
    if (random(0, 1) < transition_prob) {
      phero_type = PHERO_A;
    }
  }
}




//float Phero_c::ThetaInRange() { // makes theta into -PI, PI range and in degrees
//
//  float theta_range = fmod(current_xyt.theta, 2 * PI);
//  if (theta_range > PI) {
//    theta_range -= 2 * PI;
//  } else if (theta_range < -PI) {
//    theta_range += 2 * PI;
//  }
//  theta_range = theta_range * 180.0 / PI; // convert to degrees
//  return theta_range;
//}

float Phero_c::ThetaRange360() { // different to 3pi function as gives output in degrees in 0 - 360 range (NOT RADIANS)
  float theta_range = fmod(current_xyt.theta, 2 * PI);
  if (theta_range < 0) {
    theta_range += 2 * PI;
  }
  return theta_range * 180.0 / PI; // convert to degrees (0 to 360 range)
}


void Phero_c::fwdCell(float theta_range) { // calculates cell in front based on orientation
  //  -1  0 1 -> Robot at X
  //   0  X -
  //   1  - -

  int8_t cell_fwdX = 0;
  int8_t cell_fwdY = 0;
  if (theta_range >= 337.5 || theta_range < 22.5) { // "Right (0 degrees)"
    cell_fwdX = 1;
    cell_fwdY = 0;
  } else if (theta_range >= 22.5 && theta_range < 67.5) { // "Bottom-right (45 degrees)"
    cell_fwdX = 1;
    cell_fwdY = 1;
  } else if (theta_range >= 67.5 && theta_range < 112.5) {   // "Bottom (90 degrees)";
    cell_fwdX = 0;
    cell_fwdY = 1;
  } else if (theta_range >= 112.5 && theta_range < 157.5) {  // "Bottom-left (135 degrees)";
    cell_fwdX = -1;
    cell_fwdY = 1;
  } else if (theta_range >= 157.5 && theta_range < 202.5) { // "Left (180 degrees)";
    cell_fwdX = -1;
    cell_fwdY = 0;
  } else if (theta_range >= 202.5 && theta_range < 247.5) { // "Top-left (225 degrees)";
    cell_fwdX = -1;
    cell_fwdY = -1;
  } else if (theta_range >= 247.5 && theta_range < 292.5) {   // "Top (270 degrees)";
    cell_fwdX = 0;
    cell_fwdY = -1;
  } else if (theta_range >= 292.5 && theta_range < 337.5) { // "Top-right (315 degrees)";
    cell_fwdX = 1;
    cell_fwdY = -1;
  } else {        // "Error: Invalid angle";
    Serial.println("Problem with fwdCell function");
  }

  fwdX_local = cell_fwdX;
  fwdY_local = cell_fwdY;
  fwdX_global = pmap_x + cell_fwdX;
  fwdY_global = pmap_y + cell_fwdY;
}

//int Phero_c::angleDis(int x2, int x1, int y2, int y1, int current_angle = -1) { // doesn't need predefined angle array
//  if (x1 < -1 || x1 >= 2 || x2 < -1 || x2 >= 2 || y1 < -1 || y1 >= 2 || y2 < -1 || y2 >= 2) {
//    Serial.println("Problem with angleDis function input ");
//    return 0;
//  }
//  int8_t angle_tgt = angles[y2 + 1][x2 + 1];
//  int8_t angle_fwd = (current_angle == -1) ? angles[y1 + 1][x1 + 1] : current_angle;
//  int16_t angle_diff = angle_tgt - angle_fwd;
//  // Normalize the angle difference to be between -180 and 180
//  if (angle_diff > 180) {
//    angle_diff -= 360;
//  } else if (angle_diff < -180) {
//    angle_diff += 360;
//  }
//  return abs(angle_diff);
//}




int Phero_c::angleDis(int x2, int x1, int y2, int y1) { // Assuming a 3x3 neighbour cell input, degree output
  if (x1 < -1 || x1 >= 2 || x2 < -1 || x2 >= 2 || y1 < -1 || y1 >= 2 || y2 < -1 || y2 >= 2) {
    Serial.println("Problem with angleDis function input ");
    // Inorrect input to angleDis;
    return 0;
  }
  int8_t angle_tgt = angles[y2 + 1][x2 + 1]; // +1 to put in range [0,1,2] for array
  int8_t angle_fwd = angles[y1 + 1][x1 + 1];
  int8_t angle_turn = 0;

  if (angle_tgt > angle_fwd) {
    if (angle_tgt - angle_fwd <= 180) {
      angle_turn = angle_tgt - angle_fwd;
    } else {
      angle_turn = 360 - (angle_tgt - angle_fwd);
    }
  } else {
    if (angle_fwd - angle_tgt <= 180) {
      angle_turn = angle_fwd - angle_tgt;
    } else {
      angle_turn = 360 - (angle_fwd - angle_tgt);
    }
  }
  return angle_turn;
}


float Phero_c::AngleToCenter(int _pmap_x, int _pmap_y) { // radian output -pi to pi range - given to 3pi
  // Calculate the center of the map
  int center_x = floor((PMAP_MAX - 1) / 2);
  int center_y = floor((PMAP_MAX - 1) / 2);

  // Calculate the angle towards the center
  float dx = center_x - _pmap_x;
  float dy = center_y - _pmap_y;
  float angle_to_center = atan2(dy, dx); // Angle in radians

  return angle_to_center;
}




void Phero_c::updatePmapxy() {
  prev_x = pmap_x;
  prev_y = pmap_y;
  pmap_x = PMAP_START_X + (int)(current_xyt.x / CELL_W);
  pmap_y = PMAP_START_Y + (int)(current_xyt.y / CELL_W);
}

float Phero_c::ThetaDemand() { // set angle demand based on goal and pmap cells - output in radians
  // // Below for moving towards goal cell:
  //  int8_t dx = goalcell_x - pmap_x;
  //  int8_t dy = goalcell_y - pmap_y;
  //  float angle_demand = atan2(dy, dx);

  // random walk below
  float heading_adjust = current_xyt.theta + randGaussian( 0.0, 1.5);
  angle_demand = (angle_demand * 0.7) + (heading_adjust * 0.3);

  return angle_demand;
}

char Phero_c::encode_xy(int value) {
  if (value >= 0 && value < 51) {
    return encoding_table[value];
  } else {
    return '?'; // Error handling for out of range values
  }
}

int Phero_c::decode_xy(char character) {
  if (character < 0 || character > 127 || decoding_table[(int)character] == -1) {
    return -1; // Error handling for invalid characters
  } else {
    return decoding_table[(int)character];
  }
}

void Phero_c::addRandomCells(float _pmap[PMAP_MAX][PMAP_MAX], int startIndex, int count) {
  for (int i = 0; i < count; i++) {
    int ranX, ranY;
    float ran_pvalue;
    do {
      ranX = random(0, PMAP_MAX);
      ranY = random(0, PMAP_MAX);
      ran_pvalue = fmod(_pmap[ranY][ranX], 1.0);
    } while (ran_pvalue == 0);
    int index = startIndex + (4 * i);
    p_msg[index] = (_pmap[ranY][ranX] < 1 || (_pmap[ranY][ranX] >= 10 && _pmap[ranY][ranX] <= 11)) ? 'A' : 'B';
    p_msg[index + 1] = encode_xy(ranX);
    p_msg[index + 2] = encode_xy(ranY);
    p_msg[index + 3] = (char)('0' + (int)(ran_pvalue * 10) % 10);
  }
}

// PROBLEM WITH MSG TYPE 2 (AND IN DECODE FUNCTION OF MSG TYPE 2)

// msg type 0 (local 3x3 grid) = phero type (A or B) (1 byte) + co-ords (2bytes) + 3x3 grid of values (9 bytes)
// msg type 1 (local 5x5 grid): same as above but with 25 cells. -> may want to change RPHERO
// msg type 2 (random) = 'Z' (indicate random cells) +  N random cells * (phero type (A or B) (1 byte) + co-ords (2bytes) + phero value (1 byte))
// msg type 3 (hybrid sequential) -> sends type 0 then 2 sequentially
// msg type 4 (hybrid combination) -> sends type 0 and 2 at the same time
void Phero_c::msgUpdate(float pmap[PMAP_MAX][PMAP_MAX], int pmapx, int pmapy, char phero_type, int message_type) {
  if (phero_type != 'A' && phero_type != 'B') return; // invalid phero type

  memset(p_msg, 0, sizeof(p_msg)); // Clear entire p_msg buffer

  int msg_index = 0;

  if (message_type == 0 || message_type == 1 || (message_type == 3 && message_index_hybrid == 0)) {

    int grid_radius = message_type == 1 ? 2 : 1;
    if (message_type == 1) p_msg[msg_index++] = 'X';
    p_msg[msg_index++] = phero_type;
    p_msg[msg_index++] = encode_xy(pmapx);
    p_msg[msg_index++] = encode_xy(pmapy);


    for (int i = -grid_radius; i <= grid_radius; i++) {
      for (int j = -grid_radius; j <= grid_radius; j++) {
        int x = pmapx + j, y = pmapy + i;
        p_msg[msg_index++] = (x >= 0 && x < PMAP_MAX && y >= 0 && y < PMAP_MAX)
                             ? (char)('0' + ((int)(pmap[y][x] * 10) % 10))
                             : '0';
      }
    }
    Serial.println("Sending local pmap");
  }
  else if (message_type == 2 || (message_type == 3 && message_index_hybrid == 1)) {
    p_msg[msg_index++] = 'Z';
    addRandomCells(pmap, msg_index, n_rand_cells); // default 5
    Serial.println("Sending random cells");
  }
  else if (message_type == 4) {
    p_msg[msg_index++] = 'Y';
    p_msg[msg_index++] = phero_type;
    p_msg[msg_index++] = encode_xy(pmapx);
    p_msg[msg_index++] = encode_xy(pmapy);

    // add local 3x3 grid
    for (int i = -1; i <= 1; i++) {
      for (int j = -1; j <= 1; j++) {
        int x = pmapx + j, y = pmapy + i;
        p_msg[msg_index++] = (x >= 0 && x < PMAP_MAX && y >= 0 && y < PMAP_MAX)
                             ? (char)('0' + ((int)(pmap[y][x] * 10) % 10))
                             : '0';
      }
    }

    // add 3 random cells
    addRandomCells(pmap, msg_index, 3);
  }

  if (message_type == 3) {
    message_index_hybrid = 1 - message_index_hybrid;
  }
}

// Unpack incoming pheromone message
void Phero_c::msgDecode(char new_msg[]) {
  char msgType = new_msg[0];
  if (msgType != 'Z' && msgType != 'Y') { // local 3x3 or 5x5 grid
    processLocalMessage(new_msg);
  }  else if (msgType == 'Z') { // random 5 cells
    processRandomCellsMessage(new_msg, 1, n_rand_cells);
  } else if (msgType == 'Y') { // combined message format
    processLocalMessage(new_msg + 1);  // Process local part
    processRandomCellsMessage(new_msg, 13, 3);  // Process random cells part, now with 3 cells
  }
}

void Phero_c::processLocalMessage(char* msg) {
  bool local_5 = msg[0] == 'X' ? true : false;
  int index_2 = local_5 ? 1 : 0;

  char phero_msg_type = msg[index_2];
  int x_coord = decode_xy(msg[index_2 + 1]);
  int y_coord = decode_xy(msg[index_2 + 2]);

  if (local_5) {
    for (int i = -2, index = 5; i <= 2; i++) {
      for (int j = -2; j <= 2; j++, index++) {
        msgUpdatePmap(x_coord + j, y_coord + i, phero_msg_type, msg[index]);
      }
    }
  } else { // local 3 grid
    for (int i = -1, index = 3; i <= 1; i++) {
      for (int j = -1; j <= 1; j++, index++) {
        msgUpdatePmap(x_coord + j, y_coord + i, phero_msg_type, msg[index]);
      }
    }
  }
}

void Phero_c::processRandomCellsMessage(char* msg, int startIndex, int cellCount) {
  for (int i = 0; i < cellCount; i++) {
    int index = startIndex + (4 * i);
    char ran_phero_type = msg[index];
    int ranX = decode_xy(msg[index + 1]);
    int ranY = decode_xy(msg[index + 2]);
    msgUpdatePmap(ranX, ranY, ran_phero_type, msg[index + 3]);
  }
}

// Check incoming value is most up to date (higher than cell being updated)
// and add into correct category i.e. neighbour group A trail into 10-11 range
void Phero_c::msgUpdatePmap(int x, int y, char phero_type, char value) {
  if (x >= 0 && x < PMAP_MAX && y >= 0 && y < PMAP_MAX) {
    float auxFlt = (float)(value - '0') / 10.0f;
    float current_value = pmap[y][x];

    if (current_value >= 10 && current_value <= 11) {
      current_value -= 10;
    } else if (current_value >= 12 && current_value <= 13) {
      current_value -= 12;
    } else if (current_value >= 2 && current_value <= 3) {
      current_value -= 2;
    }

    if (auxFlt > current_value) {
      pmap[y][x] = auxFlt + (phero_type == 'A' ? 10 : 12);
    }
  }
}


// Random Gaussian used for generating theta demand
float Phero_c::randGaussian( float mean, float sd ) {
  float x1, x2, w, y;

  do {
    // Adaptation here because arduino random() returns a long
    x1 = random(0, 2000) - 1000;
    x1 *= 0.001;
    x2 = random(0, 2000) - 1000;
    x2 *= 0.001;
    w = (x1 * x1) + (x2 * x2);

  } while ( w >= 1.0 );

  w = sqrt( (-2.0 * log( w ) ) / w );
  y = x1 * w;

  return mean + y * sd;

}


//    OLD CODE BELOW

// Below coded for demo day: but needs checking (especially attractive pheromones)!

// Detection of local pheromones used for movement (repulsion or attraction to trails)
// Options: 0 no trails, 1 repulsive all, 2 attractive to other groups else random goal cell

//void Phero_c::detection(float _pmap[PMAP_MAX][PMAP_MAX], int pmapx, int pmapy, int option) {
//  if (option < 0 || option > 3) return; // Invalid option
//
//  if (option == 0) {
//    // do nothing - random walk being used.
//  } else {
//    if (option < 3) {
//
//      float prev_p = 0;
//      double prev_angle = 360; // Angle from cell in front of robot to potential target cell
//      fwdCell(ThetaRange360());
//      int8_t neighbour_cell[2] = {fwdX_local, fwdY_local}; // initialised with fwd cell
//      uint8_t extremeVal =  option == 1 ? 1: 0; // 1 for repulsion, 0 for attraction calculations
//
//      if (option == 1) { // repulsive to all trails
//
//        for (int i = -2; i < 3; i ++) {
//          for (int j = -2; j < 3; j++) {
//            if (i == 0 && j == 0) continue;
//            int8_t x = pmapx + j;
//            int8_t y = pmapy + i;
//
//            if ( x >= 0 && x < PMAP_MAX
//                 && y >= 0 && y < PMAP_MAX) {
//
//              float pmap_aux = fmod(_pmap[y][x], 1.0);
//
//              if (pmap_aux < extremeVal) {
//                extremeVal = pmap_aux;
//                neighbour_cell[0] = x;
//                neighbour_cell[1] = y;
//                prev_p = pmap_aux;
//                prev_angle = angleDis(i, fwdX_local, j, fwdY_local);
//
//              } else if (pmap_aux == prev_p) { // check for cell with closest angle
//
//                float current_angle = angleDis(j, fwdX_local, i, fwdY_local);
//                if (current_angle < prev_angle) {
//                  neighbour_cell[0] = x;
//                  neighbour_cell[1] = y;
//                  prev_angle = current_angle;
//                }
//              }
//            }
//          }
//        }
//
//      } else if (option == 2) { // attractive to neighbour trails
//        bool attractiveCell = false;
//
//        for (int i = -2; i < 3; i ++) {
//          for (int j = -2; j < 3; j++) {
//            if (i == 0 && j == 0) continue;
//            int8_t x = pmapx + j;
//            int8_t y = pmapy + i;
//
//            if ( x >= 0 && x < PMAP_MAX
//                 && y >= 0 && y < PMAP_MAX) {
//
//              float pmap_aux = _pmap[y][x];
//
//              // < 0.8 to prevent getting too close to other robots
//              if (pmap_aux > 3 && (fmod(_pmap[y][x], 1.0) < 0.8)) attractiveCell = true;
//
//
//              if (attractiveCell) {
//                pmap_aux = fmod(_pmap[y][x], 1.0);
//                if (pmap_aux > extremeVal) {
//                  extremeVal = pmap_aux;
//                  neighbour_cell[0] = x;
//                  neighbour_cell[1] = y;
//                  prev_p = pmap_aux;
//                  prev_angle = angleDis(i, fwdX_local, j, fwdY_local);
//
//                } else if (pmap_aux == prev_p) { // check for cell with closest angle
//
//                  float current_angle = angleDis(j, fwdX_local, i, fwdY_local);
//                  if (current_angle < prev_angle) {
//                    neighbour_cell[0] = x;
//                    neighbour_cell[1] = y;
//                    prev_angle = current_angle;
//                  }
//                }
//              }
//            }
//          }
//        }
//        if (!attractiveCell) { // select random goal cell if no neighbour trail
//
//          do {
//            goalcell_x = pmapx + floor(random(-1, 2));
//            goalcell_y = pmapy + floor(random(-1, 2));
//          } while ((goalcell_x == pmapx && goalcell_y == pmapy) || (goalcell_x <= 0
//                   || goalcell_x >= PMAP_MAX) || (goalcell_y <= 0 || goalcell_y >= PMAP_MAX));
//        }
//      }
//      goalcell_x = neighbour_cell[0];
//      goalcell_y = neighbour_cell[1];
//    }
//  }
//}

// Corresponding code used in main loop with above detection code, after robot
// position has been asked for (POSITION_MS)

//   if (phero.PheroTrail == 0) {
//      new_theta.theta = phero.ThetaDemand(); // set new theta demand based on goal cell or random walk
//    } else { // use trails in movement
//      new_theta.theta = (phero.angleDis(phero.goalcell_x, phero.fwdX_global,
//                                        phero.goalcell_y, phero.fwdY_global)) * PI / 180;
//    }

// From phero.h header file:
//    uint8_t PheroTrail; // 0 = random walk, 1 = Repulsive trails (to all)
// 2 = attractive trails (to groups else random walk)






// Prevents robot from leaving PMAP without needing lines or arena barriers.
// Gets robot to point to centre of PMAP
//int Phero_c::ThetaOOBS(int _fwdX_global, int _fwdY_global, int _fwdX_local, int _fwdY_local) {
//  int theta_demand = 0;
//
//  // Define a safety margin to avoid getting too close to the edges
//  const int SAFETY_MARGIN = 1;
//
//  // Helper function to choose a direction away from edges
//  auto chooseDirection = [&](int dx, int dy) {
//    return angleDis(dx, _fwdX_local, dy, _fwdY_local);
//  };
//
//  // Handle corners and near-corner situations
//  if (_fwdX_global <= SAFETY_MARGIN && _fwdY_global <= SAFETY_MARGIN) {
//    // Near top-left corner
//    return chooseDirection(1, 1); // Move towards bottom-right
//  } else if (_fwdX_global <= SAFETY_MARGIN && _fwdY_global >= PMAP_MAX - SAFETY_MARGIN) {
//    // Near bottom-left corner
//    return chooseDirection(1, -1); // Move towards top-right
//  } else if (_fwdX_global >= PMAP_MAX - SAFETY_MARGIN && _fwdY_global <= SAFETY_MARGIN) {
//    // Near top-right corner
//    return chooseDirection(-1, 1); // Move towards bottom-left
//  } else if (_fwdX_global >= PMAP_MAX - SAFETY_MARGIN && _fwdY_global >= PMAP_MAX - SAFETY_MARGIN) {
//    // Near bottom-right corner
//    return chooseDirection(-1, -1); // Move towards top-left
//  }
//
//  // Handle edges
//  if (_fwdX_global <= SAFETY_MARGIN) {
//    // Near left edge
//    return chooseDirection(1, 0);
//  } else if (_fwdX_global >= PMAP_MAX - SAFETY_MARGIN) {
//    // Near right edge
//    return chooseDirection(-1, 0);
//  } else if (_fwdY_global <= SAFETY_MARGIN) {
//    // Near top edge
//    return chooseDirection(0, 1);
//  } else if (_fwdY_global >= PMAP_MAX - SAFETY_MARGIN) {
//    // Near bottom edge
//    return chooseDirection(0, -1);
//  }
//
//  // If we're here, we're not near any edge or corner
//  return 0;
//}
