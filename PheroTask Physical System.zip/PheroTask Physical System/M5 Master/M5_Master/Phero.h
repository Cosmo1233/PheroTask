
#ifndef _PHERO_H
#define _PHERO_H
#define PI 3.14159265358979323846
#define CELL_W 20 // each cell has CELL_W mm width - arena width (i.e. 1m) / PMAP_MAX
#define PMAP_MAX 50//(2*ARENA_RADIUS)/CELL_W 

//#define ENC_CELL 178 encoder counts per one 5 x 5 cm cell
//#define R_PHERO 1 // Moore's neighbourhood of cells -> could change to 2?
#define PMAP_START_X 24
#define PMAP_START_Y 24

#define ALPHA 0.5

#define PHERO_A 'A'
#define PHERO_B 'B'


#include <Wire.h>           // i2c to connect to IR communication board.
#include <Arduino.h>
#include "i2c_3pi_data.h"

extern i2c_3pi_xyt_t current_xyt;
extern i2c_3pi_th_demand_t   new_theta;
extern uint8_t current_run;

class Phero_c {
  public:

    Phero_c();

    int8_t pmap_x; // current pmap cell x co-ordinate
    int8_t pmap_y; // current pmap cell y co-ordinate
    int8_t prev_x; // previous pmap cell x
    int8_t prev_y; // previous pmap cell y
    int8_t goalcell_x; // target pmap cell x
    int8_t goalcell_y; // target pmap cell y
    int8_t fwdX_local; // x, y of forward cell in local 3x3 cell neighbourhood (-1,0,1)
    int8_t fwdY_local;
    int fwdX_global; // x, y of forward cell global
    int fwdY_global;
    uint16_t angles[3][3] = {
      {225, 270, 315},
      {180, 0, 0},
      {135, 90, 45}
    };
    int decoding_table[128];

    uint8_t NEW_START_X;
    uint8_t NEW_START_Y;
    uint8_t R_PHERO; // diffusion constant in cells

    double theta;

    float theta_range;
    float angle_demand;
    //    static const int8_t fwd = 25;
    //    float turn; // add in if collision turn is different

    float pmap[PMAP_MAX][PMAP_MAX]; // Pheromone map

    float diffusion; // diffusion value (used in deposition function)
    float evaporation;

    float groupA_size;
    float groupB_size;

    
    float targetA_size;
    float targetB_size;
    float hysteresis; // used in group assessment function

    int group_switches;
    //    int max_repulsive = 1;
    //    int max_attractive = 3;
    int max_A = 1;
    int max_B = 3;

    int message_type;
    int message_index_hybrid; // used for hybrid sequential type
    uint8_t n_rand_cells;

    char phero_type; // determines type of pheromone deposited


    bool initialised;
    bool local_msg;

    char p_msg[28]; // local pheromone msg to send

    // Used for encoding pmap co-ordinates,
    char encoding_table[52] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmno";


    void initialise();
    void update();
    void deposition(float _pmap[PMAP_MAX][PMAP_MAX], int _pmap_x, int _pmap_y, float evap, char _phero_type);
    void detection(float _pmap[PMAP_MAX][PMAP_MAX], int pmapx, int pmapy, int option);
    //    void msgUpdate(float _pmap[PMAP_MAX][PMAP_MAX], int _pmapx, int _pmapy, char _phero_type, int _message_type);
    void msgUpdate(float _pmap[PMAP_MAX][PMAP_MAX], int _pmapx, int _pmapy, char _phero_type, int _message_type);

    void msgDecode(char new_msg[]);
    void groupEstimate(float _pmap[PMAP_MAX][PMAP_MAX], int _pmap_x, int _pmap_y);
    void groupChange(char current_group, float _groupA_size, float _groupB_size, float tgt_val_A, float tgt_val_B, float hysteresis);
    void printPmap();
    void updatePmapxy();
    //    float ThetaInRange();
    float ThetaRange360();
    float ThetaDemand();
    //    int ThetaOOBS(int _fwdX_global, int _fwdY_global, int _fwdX_local, int _fwdY_local);
    float AngleToCenter(int _pmap_x, int _pmap_y);
    void fwdCell(float theta_range);
    int angleDis(int x2, int x1, int y2, int y1);
    char encode_xy(int value);
    int decode_xy(char character);
    float randGaussian( float mean, float sd );

    void addRandomCells(float _pmap[PMAP_MAX][PMAP_MAX], int startIndex, int count);
    void processLocalMessage(char* msg);
    void processRandomCellsMessage(char* msg, int startIndex, int cellCount);
    void msgUpdatePmap(int x, int y, char phero_type, char value);


};

#endif
