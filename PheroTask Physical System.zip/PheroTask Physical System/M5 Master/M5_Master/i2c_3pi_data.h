
#ifndef _3PI_I2C_DATA_H
#define _3PI_I2C_DATA_H

// Data to send(tx) and receive(rx)
// on the i2c bus.
// Needs to match the master device
// Note that the Arduino is limited to
// a buffer of 32 bytes!
#pragma pack 1


#define MODE_3PI_NEW_THETA      0
#define MODE_3PI_NEW_STRING     1
#define MODE_3PI_REPORT_XYT     2
#define MODE_3PI_REPORT_STATE   3
#define MODE_3PI_STOP           4
#define MODE_NOT_SET            5
#define MODE_3PI_OUT_BOUNDS     6
#define MODE_3PI_RESET          7 // For between runs

//#define MODE_3PI_REPORT_BUMPERS 2



// Used to set the mode of the 3Pi robot
// and for the M5 to request specific data
typedef struct i2c_3pi_mode {
  uint8_t flag;
} i2c_3pi_mode_t;

// X,Y,Theta positions
typedef struct i2c_3pi_xyt {
  float x;                  // 4 bytes
  float y;                  // 4 bytes
  float theta;              // 4 bytes
} i2c_3pi_xyt_t;

// To send theta demand
typedef struct i2c_3pi_th_demand {
  float theta;
} i2c_3pi_th_demand_t;

// Helpful to see what state robot is in:
typedef struct i2c_3pi_status {
  // States correlate to FSM behaviours on 3pi
  // 0 = Driving, 1 = Waiting, 2 = Obstacle, 3 = Line (Arena boundary), 3 = OOBs (not used), 4 = reset
  uint8_t mode;
} i2c_3pi_status_t;


// It might be convenient to simply send a string
// of all the data you want?
typedef struct i2c_3pi_string {
  char str[32];   // 32 is max.  To improve the
  // efficiency you could reduce
  // this to match your need.
  // Remember! Needs to be same on
  // master and slave.
} i2c_3pi_string_t;



//// Bump sensors...
//typedef struct i2c_3pi_bump {
//  uint16_t  left;
//  uint16_t  right;
//} i2c_3pi_bump_t;


#endif
