#include "ircomm.h"
#include <Wire.h>

IRComm_c::IRComm_c() {}

void IRComm_c::initialise() {
  msg_check = false;
}



// Use this function to set a message to transmit to
// other robots.
void  IRComm_c::setIRMessage(char* str_to_send, int len) {

  // Message must be shorter than 32 bytes
  // and at least 1 byte.
  if ( len <= 32 && len >= 1 ) {

    // The communication board will always default
    // to waiting to receive a message to transmit
    // so we don't need to change the mode.
    Wire.beginTransmission( ADDR_IRCOMM );
    Wire.write( (byte*)str_to_send, len);
    Wire.endTransmission();
  }
}

void  IRComm_c::getSensors() {
  // Set mode to read fetch sensor data
  ircomm_mode.mode = MODE_REPORT_SENSORS;
  Wire.beginTransmission( ADDR_IRCOMM );
  Wire.write( (byte*)&ircomm_mode, sizeof( ircomm_mode));
  Wire.endTransmission();

  // struct to store sensor data
  i2c_sensors_t sensors;

  // Read across bytes
  Wire.requestFrom( ADDR_IRCOMM, sizeof( sensors ));
  Wire.readBytes( (uint8_t*)&sensors, sizeof( sensors ));

  Serial.println("Sensors:");
  Serial.print(" - LDR: ");
  for (int i = 0; i < 3; i++ ) {
    Serial.print( sensors.ldr[i] );
    Serial.print(",");
  }
  Serial.print("\n - Prox:");
  for (int i = 0; i < 2; i++ ) {
    Serial.print( sensors.prox[i] );
    Serial.print(",");
  }
  Serial.println();

}

// Get the latest message from the communication board
// from receiver "which_rx" (0,1,2,3).
// This is a little bit more complicated because we don't
// know how long a message will be. So we have to first
// ask how many bytes are available (present).

void  IRComm_c::getIRMessage(int which_rx ) {
  // Select right mode to ask how many bytes are
  // available.
  if ( which_rx < 0 || which_rx > 3 ) {
    // catch error first.
    msg_check = false;
    return;

    //  check size of incoming messages
  } else if ( which_rx == 0 ) {
    ircomm_mode.mode = MODE_SIZE_MSG0;
  } else if ( which_rx == 1 ) {
    ircomm_mode.mode = MODE_SIZE_MSG1;
  } else if ( which_rx == 2 ) {
    ircomm_mode.mode = MODE_SIZE_MSG2;
  } else if ( which_rx == 3 ) {
    ircomm_mode.mode = MODE_SIZE_MSG3;
  }

  // Set mode to read back how many bytes are
  // available.
  Wire.beginTransmission( ADDR_IRCOMM );
  Wire.write( (byte*)&ircomm_mode, sizeof( ircomm_mode));
  Wire.endTransmission();

  // We'll use this struct to check how many
  // bytes are available of a message.
  // 0 bytes means no message.
  i2c_mode msg_status;

  // Request the message size to be sent across into
  // msg_status (n_bytes)
  Wire.requestFrom( ADDR_IRCOMM, sizeof( msg_status ));
  Wire.readBytes( (uint8_t*)&msg_status, sizeof( msg_status ));

  // If data is available, we change mode to read it
  // across.
  if ( msg_status.mode <= 0 || msg_status.mode > 32 ) {
    // catch error first
    // message size shouldn't be -ve, 0 or more than
    // 32 bytes.
    msg_check = false;
    return;

  } else { //bytes available > 0
    // Format mode request for which receiver
    if ( which_rx == 0 ) {
      ircomm_mode.mode = MODE_REPORT_MSG0;
    } else if ( which_rx == 1 ) {
      ircomm_mode.mode = MODE_REPORT_MSG1;
    }  else if ( which_rx == 2 ) {
      ircomm_mode.mode = MODE_REPORT_MSG2;
    }  else if ( which_rx == 3 ) {
      ircomm_mode.mode = MODE_REPORT_MSG3;
    } else {
      // error should have been caught much earlier.
    }

    // Set mode to send across a full message
    Wire.beginTransmission( ADDR_IRCOMM );
    Wire.write( (byte*)&ircomm_mode, sizeof( ircomm_mode));
    Wire.endTransmission();

    // char array to store message into
    char buf[32];
    int count = 0;
    Wire.requestFrom( ADDR_IRCOMM, msg_status.mode );
    while ( Wire.available() && count < 32 ) {
      char c = Wire.read();
      buf[count] = c;
      count++;
    }

    memcpy( receivedMsg, buf, sizeof( buf ));

    // Mainly debugging here.
    // Need to decide what to do with the char array
    // once a message has been sent across.
    if ( count > 0 ) {
      Serial.print("Rx" );
      Serial.print( which_rx );
      Serial.print(":\t");
      for ( int i = 0; i < count; i++ ) {
        Serial.print( buf[i]  );
      }
      Serial.println();
      Serial.println( buf );
    }
    msg_check = true;
  }
  return;
}

void IRComm_c::statusRequest() {
  // Set mode to status request
  ircomm_mode.mode = MODE_REPORT_STATUS;
  Wire.beginTransmission( ADDR_IRCOMM );
  Wire.write( (byte*)&ircomm_mode, sizeof( ircomm_mode));
  Wire.endTransmission();

  // Get the data from the device
  Wire.requestFrom( ADDR_IRCOMM, sizeof( ircomm_status ));
  Wire.readBytes( (uint8_t*)&ircomm_status, sizeof( ircomm_status ));


  // Report how many messages have been received on each
  // receiver
  Serial.print("Msg Pass:\t");
  for ( int i = 0; i < 4; i++ ) {
    Serial.print( ircomm_status.pass_count[i] );
    Serial.print("\t");
  }
  Serial.println();
  Serial.print("Msg Fail:\t");
  for ( int i = 0; i < 4; i++ ) {
    Serial.print( ircomm_status.fail_count[i] );
    Serial.print("\t");
  }
  Serial.println();

  // Print the same to the LCD
  //  M5.Lcd.setTextSize(1);
  //  M5.Lcd.print("Msg Pass: ");
  //  for ( int i = 0; i < 4; i++ ) {
  //    M5.Lcd.print( ircomm_status.pass_count[i] );
  //    M5.Lcd.print(" ");
  //  }
  //  M5.Lcd.println();
  //  M5.Lcd.print("Msg Fail: ");
  //  for ( int i = 0; i < 4; i++ ) {
  //    M5.Lcd.print( ircomm_status.fail_count[i] );
  //    M5.Lcd.print(" ");
  //  }
  //  M5.Lcd.println();


  // Test for getting data from extra sensors.
  getSensors();
}

void IRComm_c::resetCounts() {
  // Set mode to reset counts
  ircomm_mode.mode = MODE_RESET_COUNTS;
  Wire.beginTransmission( ADDR_IRCOMM );
  Wire.write( (byte*)&ircomm_mode, sizeof( ircomm_mode));
  Wire.endTransmission();

}
