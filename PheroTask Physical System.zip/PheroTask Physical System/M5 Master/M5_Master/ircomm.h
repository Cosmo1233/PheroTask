#ifndef IRCOMM_H
#define IRCOMM_H

#include "Arduino.h"
#include "Wire.h"
#include "ircomm_data.h"

#define ADDR_IRCOMM 0x08

class IRComm_c {
  private:
  public:
    IRComm_c();

    // A data structure to communicate the mode.
    // Keep consistent between devices.
    i2c_mode_t ircomm_mode;

    // A data structure to receive back the status of the board.
    // Keep consistent between devices.
    i2c_status_t ircomm_status;

    i2c_msg_status_t ircomm_msg_status;
    i2c_msg_timings_t ircomm_msg_timings;
    i2c_activity_t ircomm_activity;
    i2c_bearing_t ircomm_bearing;
    i2c_id_hist_t ircomm_id_hist;
    i2c_sensors_t ircomm_sensors;

    bool msg_check;       // check for message
    char receivedMsg[32]; // message received from ircomm

    void initialise();
    void setIRMessage(char* str_to_send, int len);
    void getSensors();
    void getIRMessage(int which_rx);
    void statusRequest();
    void resetCounts();
};

#endif
