//kinematics.cpp
#include "kinematics.h"

Kinematics_c::Kinematics_c() {
}

void Kinematics_c::initialise() {
  x = 0;
  y = 0;
  x_old = 0;
  y_old = 0;
  theta = 0;
  theta_old = 0;
  x_r = 0;
  theta_r = 0;
}

void Kinematics_c::update() {
  // Update kinematics
  // Implementation of the update method
  long dec_el = (count_el - count_el_old);
  long dec_er = (count_er - count_er_old);
  float dec_el_flt = static_cast<float>(dec_el);
  float dec_er_flt = static_cast<float>(dec_er);

  count_el_old = count_el;
  count_er_old = count_er;

  x_r = (((dec_el_flt * enc_to_mm) / 2.0) + ((dec_er_flt * enc_to_mm) / 2.0));
  x = x_old + (x_r * cos(theta_old));
  y = y_old + (x_r * sin(theta_old));

  theta_r = ((dec_el_flt * enc_to_mm) / (2.0 * l_value)) - ((dec_er_flt * enc_to_mm) / (2.0 * l_value));
  theta = theta_old + theta_r;
  theta_deg = theta * (180 / PI);

  x_old = x;
  y_old = y;
  theta_old = theta;


}

float Kinematics_c::getDistanceFromOrigin() {
  float d;
  d = sqrt( pow( x, 2) + pow( y, 2) );
  return d;
}

//float Kinematics_c::ThetaInRange() {
//  float theta_aux = theta_deg;
//  if ( theta_aux < 0) {
//    while ( theta_aux < 0) {
//      theta_aux += 360;
//    }
//  }
//  if (theta_aux > 360) {
//    while ( theta_aux > 360) {
//      theta_aux -= 360;
//    }
//  }
//  float theta_range = fmod(theta_aux, 360.0); // keeping robot theta in [0, 360] range.
//  return theta_range;
//}

float Kinematics_c::ThetaInRange() { // in radians, in -pi to pi range.
  update();
  float theta_range = fmod(theta, 2 * PI);
  if (theta_range > PI) {
    theta_range -= 2 * PI;
  } else if (theta_range < -PI) {
    theta_range += 2 * PI;
  }
  return theta_range;
}

//float Kinematics_c::ThetaInRange() {
//  float theta_range = fmod(theta, 2 * PI);
//  if (theta_range < 0) {
//    theta_range += 2 * PI;
//  }
//  return theta_range * 180.0 / PI; // convert to degrees (0 to 360 range)
//}

void Kinematics_c::print() {
  Serial.print( x );
  Serial.print( "," );
  Serial.print( y );
  Serial.print( "," );
  Serial.println( theta );

  return;

}
