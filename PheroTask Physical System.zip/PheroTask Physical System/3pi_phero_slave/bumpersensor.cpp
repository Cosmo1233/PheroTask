#include "bumpersensor.h"
#include <Arduino.h>

// Constructor
BumperSensor_c::BumperSensor_c() {
}

void BumperSensor_c::calibration() {
  uint8_t index = 0;

  //  tone(BUZZER_PIN, 150);
  //  delay(50);
  //  noTone(BUZZER_PIN);
  //  delay(500);

  while (index < 30) {
    readBumperSensors();
    calib_array[0][index] = bumper_dec[0];
    calib_array[1][index] = bumper_dec[1];
    index += 1;
    delay(50);
  }

  //  tone(BUZZER_PIN, 150);
  //  delay(50);
  //  noTone(BUZZER_PIN);



  int numCols = sizeof(calib_array[0]) / sizeof(calib_array[0][0]);
  float maxVal_l = calib_array[0][0];
  float minVal_l = calib_array[0][0];
  float maxVal_r = calib_array[1][0];
  float minVal_r = calib_array[1][0];

  for (int i = 0; i < numCols; i++) { // Finding max and min values of sample readings
    float current_l = calib_array[0][i];
    float current_r = calib_array[1][i];
    // Update max and min values if necessary.
    if (current_l > maxVal_l) maxVal_l = current_l;
    if (current_l < minVal_l)minVal_l = current_l;
    if (current_r > maxVal_r) maxVal_r = current_r;
    if (current_r < minVal_r) minVal_r = current_r;

    b_thresh[0] = ((maxVal_l + minVal_l) / 2.0) + 110;
    b_thresh[1] = ((maxVal_r + minVal_r) / 2.0) + 110;
  }
}


void BumperSensor_c::readBumperSensors() {
  for (int i = 0; i < 2; i++) {
    pinMode(EMIT_PIN, OUTPUT);
    digitalWrite(EMIT_PIN, LOW);

    pinMode(b_pins[i], OUTPUT); // changing the specific pins state

    digitalWrite(b_pins[i], HIGH);
    delayMicroseconds(10);

    pinMode(b_pins[i], INPUT);
    unsigned long start_t = micros();

    while (digitalRead(b_pins[i]) == HIGH) {
    }

    unsigned long end_t = micros(); // may need changing
    pinMode(EMIT_PIN, OUTPUT);

    unsigned long elapsed_time = end_t - start_t;
    bumper_dec[i] = elapsed_time;
  }

  bumper_sum = (bumper_dec[0] + bumper_dec[1]) / 2.0;
  lpf = (lpf * 0.8) + (bumper_sum * 0.2);
}

bool BumperSensor_c::BumperDetector() {
  readBumperSensors();
  if (bumper_dec[0] >= b_thresh[0] || bumper_dec[1] >= b_thresh[1]) {
    bumper_state = true;
  } else {
    bumper_state = false;
  }
  return bumper_state;
}

//float BumperSensor_c::weightedBumper() {
//  readBumperSensors();
//  float sum_bumpers = bumper_dec[0] + bumper_dec[1];
//  float norm_readings[2] = {0};
//
//  for (int i = 0; i < 2; i++) {
//    float norm_loop = (bumper_dec[i] / sum_bumpers);
//    norm_readings[i] = norm_loop * 2;
//  }
//  weighted_bumper = norm_readings[0] - norm_readings[1];
//
//  return weighted_bumper;
//}

//void BumperSensor_c::ObjectPush() {
//  int BiasPWM = 25;  // normally 30
//  int MaxTurnPWM = 30 ; // normally 35
//
//  unsigned long time_loop = millis();
//  BumperDetector();
//
//  if (bumper_state == true) { // Object detected
//    weightedBumper();
//    left_PWM = (BiasPWM - (weighted_bumper * MaxTurnPWM));
//    right_PWM = (BiasPWM + (weighted_bumper * MaxTurnPWM));
//    int abs_left_PWM = abs(left_PWM);
//    int abs_right_PWM = abs(right_PWM);
//
//    if (abs_left_PWM < MinPWM && abs_right_PWM < MinPWM) {
//      motors.setMotorPWM(MinPWM, MinPWM);
//    } else if (abs_left_PWM < MinPWM && abs_right_PWM > MinPWM) {
//      motors.setMotorPWM(0, right_PWM);
//    } else if (abs_left_PWM > MinPWM && abs_right_PWM < MinPWM) {
//      motors.setMotorPWM(left_PWM, 0);
//    } else {
//      motors.setMotorPWM(left_PWM, right_PWM);
//    }
//  } else if (bumper_state == false) { // No object
//    motors.setMotorPWM(0, 0);
//  } else {
//    // Do nothing
//  }
//}


//void BumperSensor_c::BumpEmit() {
//  for (int i = 0; i < 2; i++) {
//    pinMode(EMIT_PIN, OUTPUT);
//    digitalWrite(EMIT_PIN, LOW);
//
//    pinMode(b_pins[i], OUTPUT); // changing the specific pins state
//
//    digitalWrite(b_pins[i], HIGH);
//    delayMicroseconds(10);
//  }
//}


//  //  Angle turn calibration below:
//  float angle_increment = 0.20943951; // 12 deg in radians
//  int turn = 30;
//
//  while (abs(kinematics.theta) <  6.4) {//(calib_array_check < 30); // 30 initial readings
//    kinematics.update();
//    motors.setMotorPWM(turn, -turn);
//    Serial.println("Angle: " + String(kinematics.theta) + " abs angle: " + String(abs(kinematics.theta)));
//    delay(2);
//
//    if (fmod(abs(kinematics.theta), angle_increment) <= 0.1) { // get reading every 12 degrees
//      Serial.println("Getting a reading...");
//      readBumperSensors();
//      calib_array[0][calib_array_check] = bumper_dec[0];
//      calib_array[1][calib_array_check] = bumper_dec[1];
//      calib_array_check += 1;
//    }
//  }
//  motors.setMotorPWM(0, 0);
