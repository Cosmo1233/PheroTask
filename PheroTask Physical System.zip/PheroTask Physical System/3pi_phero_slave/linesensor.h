// this #ifndef stops this file
// from being included more than
// once by the compiler.
#ifndef _LINESENSOR_H
#define _LINESENSOR_H

class LineSensor_c {

  public:
#define EMIT_PIN    11    // IR LED 
#define LS_LEFT_PIN 12   // DN1
#define LS_MIDLEFT_PIN 18  // DN2 
#define LS_MIDDLE_PIN 20   // DN3
#define LS_MIDRIGHT_PIN 21  // DN4 
#define LS_RIGHT_PIN 22   // DN5

    int ls_pins[5] = {LS_LEFT_PIN,
                      LS_MIDLEFT_PIN,
                      LS_MIDDLE_PIN,
                      LS_MIDRIGHT_PIN,
                      LS_RIGHT_PIN
                     };
    int line_dec[5] = {0};
    int DN_thresh[5] = {0};
    int calib_array[5][10];
    bool DN_flags[5];

    // Constructor, must exist.
    LineSensor_c() {

    }

    void calibration() {
      pinMode(EMIT_PIN, INPUT);
      pinMode(LS_LEFT_PIN, INPUT);
      pinMode(LS_MIDLEFT_PIN, INPUT);
      pinMode(LS_MIDDLE_PIN, INPUT);
      pinMode(LS_MIDRIGHT_PIN, INPUT);
      pinMode(LS_RIGHT_PIN, INPUT);

      const int num_readings = sizeof(calib_array[0]) / sizeof(calib_array[0][0]);

      for (int index = 0; index < num_readings; index++) {
        readLineSensors();
        for (int j = 0; j < 5; j++) {
          calib_array[j][index] = line_dec[j];
        }
        delay(50);
      }

      for (int j = 0; j < 5; j++) {
        long avg_reading = 0;
        for (int i = 0; i < num_readings; i++) {
          avg_reading += calib_array[j][i];
        }
        DN_thresh[j] = (int)(avg_reading / num_readings) + 500; // ~500 difference between white and line
      }

      for (int i = 0; i < 5; i++) {
        DN_flags[i] = false;
      }
      
    }

    void readLineSensors() {
      for (int i = 0; i < 5; i++) {

        pinMode( EMIT_PIN, OUTPUT );
        digitalWrite( EMIT_PIN, HIGH );

        pinMode( ls_pins[ i ], OUTPUT ); // changing the specific pins state

        digitalWrite( ls_pins[ i ], HIGH );
        delayMicroseconds( 10 );

        pinMode( ls_pins[ i ], INPUT);
        unsigned long start_t = micros();  // be careful of the DIFFERENT TIME VARIABLES!!

        while ( digitalRead( ls_pins[ i ]) == HIGH ) {
          // Do nothing here (waiting).
        }

        unsigned long end_t = micros(); // may need changing
        pinMode( EMIT_PIN, INPUT );

        unsigned long elapsed_time = end_t - start_t;
        line_dec[i] = elapsed_time;
      }
    }

    bool LineDetector() {
      readLineSensors();
      for (int i = 0; i < 5; i++) {
        if (line_dec[i] > DN_thresh[i]) {
          DN_flags[i] = true;
        } else {
          DN_flags[i] = false;
        }
      }

      if (DN_flags[0] || DN_flags[1] || DN_flags[2] || DN_flags[3] || DN_flags[4]) {
        return true; // Line detected - at arena boundary
      }
      else {
        return false; // Robot is in arena
      }
    }

};



#endif
