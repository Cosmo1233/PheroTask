#ifndef _ENCODERS_H  
#define _ENCODERS_H

#include <Arduino.h>

#define ENCODER_0_A_PIN  7
#define ENCODER_0_B_PIN  23
#define ENCODER_1_A_PIN  26

extern volatile long count_er;
extern volatile byte state_er;
extern volatile long count_el;
extern volatile byte state_el;

void setupEncoderRight();
void setupEncoderLeft();

#endif
