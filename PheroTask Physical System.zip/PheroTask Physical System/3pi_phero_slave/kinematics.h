#ifndef KINEMATICS_H
#define KINEMATICS_H

#include "encoders.h"
#include <Arduino.h>

#define PI 3.14159265358979323846


class Kinematics_c {
  public:
    static const int r_value = 16;
    static constexpr float enc_to_mm = 0.2805776302;
    static constexpr float rad_to_deg = 57.2957795;
    static constexpr float l_value = 41;


    long count_el_old;
    long count_er_old;

    float x;
    float y;
    float x_old;
    float y_old;
    float theta;
    float theta_deg;
    float theta_old;
    float x_r;
    float theta_r;

    Kinematics_c();
    void initialise();
    void update();
    float getDistanceFromOrigin();
    float ThetaInRange();
    void print();
};

#endif
