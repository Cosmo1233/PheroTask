// motor.h
#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

#define MinPWM 20
#define MaxPWM 150
#define L_PWM_PIN 10
#define L_DIR_PIN 16
#define R_PWM_PIN 9
#define R_DIR_PIN 15
#define FWD LOW
#define REV HIGH

class Motors_c {
public:
    Motors_c(); 
    void initialise();
    void setMotorPWM(float left_pwm, float right_pwm);
};

#endif
