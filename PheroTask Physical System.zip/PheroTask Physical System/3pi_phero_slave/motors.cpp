// motor.cpp
#include "motors.h"

Motors_c::Motors_c() {
}

void Motors_c::initialise() {
  pinMode(L_PWM_PIN, OUTPUT);
  pinMode(L_DIR_PIN, OUTPUT);
  pinMode(R_PWM_PIN, OUTPUT);
  pinMode(R_DIR_PIN, OUTPUT);

  digitalWrite(L_PWM_PIN, 0);
  digitalWrite(R_PWM_PIN, 0);
  digitalWrite(L_DIR_PIN, FWD);
  digitalWrite(R_DIR_PIN, FWD);
}

void Motors_c::setMotorPWM(float left_pwm, float right_pwm) {
  digitalWrite(L_DIR_PIN, (left_pwm >= 0) ? FWD : REV);
  digitalWrite(R_DIR_PIN, (right_pwm >= 0) ? FWD : REV);

  int abs_left = abs(left_pwm);
  int abs_right = abs(right_pwm);

  if (!(abs_left == 0 && abs_right == 0)) {
    if (MinPWM < abs_left) abs_left = MinPWM;
    if (MinPWM < abs_right) abs_right = MinPWM;
    if (MaxPWM < abs_left) abs_left = MaxPWM;
    if (MaxPWM < abs_right) abs_right = MaxPWM;
  }
  analogWrite(L_PWM_PIN, abs_left);
  analogWrite(R_PWM_PIN, abs_right);


  delay(5);

}
