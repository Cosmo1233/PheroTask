#ifndef _BUMPERSENSOR_H
#define _BUMPERSENSOR_H

#include "motors.h"
#include "encoders.h"
#include "kinematics.h"

extern Motors_c motors;
extern Kinematics_c kinematics;

class BumperSensor_c {
  public:
    // Constructor
    BumperSensor_c();

    static const int EMIT_PIN = 11;    // IR LED
    static const int BL_PIN = 4;       // Left Bumper Pin
    static const int BR_PIN = 5;       // Right Bumper Pin
    static const int BUZZER_PIN = 6;

    int b_pins[2] = {BL_PIN, BR_PIN};

    float bumper_dec[2] = {0}; // [0] = left, [1] = right
    float bumper_sum; // Average of both bumper readings
    float calib_array[2][30] = {0}; // Row 1: left, Row 2: right

    float b_thresh[2] = {0}; // 0 = left, 1 = right
    float W_thresh;

    float weighted_bumper;
    float left_PWM;
    float right_PWM;

    bool bumper_state;
    float lpf = 0.0;

    void calibration();
    void readBumperSensors();
    bool BumperDetector();

    //    void BumpEmit();
    //    float weightedBumper();
    //    void ObjectPush();


};

#endif
